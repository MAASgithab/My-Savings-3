@extends('templates.app')

@section('content')

@endsection
